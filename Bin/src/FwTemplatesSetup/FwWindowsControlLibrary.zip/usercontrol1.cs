// ---------------------------------------------------------------------------------------------
#region // Copyright (c) $year$, SIL International. All Rights Reserved.
// <copyright from='$year$' to='$year$' company='SIL International'>
//		Copyright (c) $year$, SIL International. All Rights Reserved.
//
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright>
#endregion
//
// File: $itemname$.cs
// Responsibility: $full_username$
// ---------------------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace $fwrootnamespace$
{
	/// ----------------------------------------------------------------------------------------
	/// <summary>
	///
	/// </summary>
	/// ----------------------------------------------------------------------------------------
	public partial class UserControl1: UserControl
	{
		/// ------------------------------------------------------------------------------------
		/// <summary>
		///
		/// </summary>
		/// ------------------------------------------------------------------------------------
		public UserControl1()
		{
			InitializeComponent();
		}
	}
}