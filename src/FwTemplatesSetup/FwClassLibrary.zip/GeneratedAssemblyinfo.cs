﻿// ---------------------------------------------------------------------------------------------
#region // Copyright (c) $year$, SIL International. All Rights Reserved.
// <copyright from='$year$' to='$year$' company='SIL International'>
//		Copyright (c) $year$, SIL International. All Rights Reserved.
//
//		Distributable under the terms of either the Common Public License or the
//		GNU Lesser General Public License, as specified in the LICENSING.txt file.
// </copyright> 
#endregion
//
// <remarks>
// </remarks>
// ---------------------------------------------------------------------------------------------
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

